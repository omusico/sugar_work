<?php
/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Contacts"]["subpanel_setup"]["realty_contacts"] = array (
    'order' => 100,
    'module' => 'Realty',
    'subpanel_name' => 'ForContacts',
    'get_subpanel_data' => 'realty_contacts',
    'add_subpanel_data' => 'realty_id',
    'title_key' => 'LBL_REALTY_CONTACTS',
);
<?php
/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
//$layout_defs["Accounts"]["subpanel_setup"]["realty_accounts"] = array (
//    'order' => 2,
//    'module' => 'Realty',
//    'subpanel_name' => 'default',
//    'sort_order' => 'desc',
//    'sort_by' => 'date_entered',
//    'title_key' => 'LBL_SUBPANEL_REALTY_ACCOUNTS_TITLE',
//    'get_subpanel_data' => 'realty_accounts',
//    'top_buttons' =>
//    array (
//        0 =>
//        array (
//            'widget_class' => 'SubPanelTopButtonQuickCreate',
//        ),
//        1 =>
//        array (
//            'widget_class' => 'SubPanelTopSelectButton',
//            'mode' => 'MultiSelect',
//        ),
//    ),
//);

$layout_defs["Accounts"]["subpanel_setup"]["realty_accounts_m_to_m"] = array (
    'order' => 100,
    'module' => 'Realty',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_accounts_m_to_m',
    'add_subpanel_data' => 'account_id',
    'title_key' => 'LBL_REALTY_ACCOUNTS',
);
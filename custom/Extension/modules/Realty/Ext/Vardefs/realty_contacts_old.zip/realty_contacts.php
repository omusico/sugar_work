<?php
/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$dictionary['Realty']['fields']['realty_contacts'] =
    array (
        'name' => 'realty_contacts',
        'type' => 'link',
        'relationship' => 'realty_contacts',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_CONTACTS',
    );

$dictionary['Realty']['fields']['realty_contacts_rent'] =
    array (
        'name' => 'realty_contacts_rent',
        'type' => 'link',
        'relationship' => 'realty_contacts_rent',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_CONTACTS_RENT',
    );

$dictionary['Realty']['fields']['realty_contacts_buying'] =
    array (
        'name' => 'realty_contacts_buying',
        'type' => 'link',
        'relationship' => 'realty_contacts_buying',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_CONTACTS_BUYING',
    );
<?php

$mod_strings['LBL_SUGARTALK_SMS'] = 'SMS';
$mod_strings['LBL_REALTY_CONTACTS_SUITABLE'] = 'Потенциальные клиенты (физ. лица)';
$mod_strings['LBL_REALTY_ACCOUNTS_SUITABLE'] = 'Потенциальные клиенты (юр. лица)';


?>

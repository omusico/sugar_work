<?php 
 // created: 2013-02-12 12:59:27

							$mod_strings['LBL_SUGARTALK_SMS'] = 'SMS';
							?>
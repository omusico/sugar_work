<?php
 // created: 2013-02-12 15:23:05
$dictionary['Realty']['fields']['owner_first_name']['audited']=true;
$dictionary['Realty']['fields']['owner_first_name']['merge_filter']='disabled';

 ?>
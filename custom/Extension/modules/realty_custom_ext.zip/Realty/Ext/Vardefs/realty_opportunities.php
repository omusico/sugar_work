<?php
/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$dictionary['Realty']['fields']['realty_opportunities'] =
    array (
        'name' => 'realty_opportunities',
        'type' => 'link',
        'relationship' => 'realty_opportunities',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_OPPORTUNITIES',
    );
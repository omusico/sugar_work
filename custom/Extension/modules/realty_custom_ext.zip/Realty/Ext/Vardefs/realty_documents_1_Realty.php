<?php
// created: 2013-07-03 14:00:07
$dictionary["Realty"]["fields"]["realty_documents_1"] = array (
  'name' => 'realty_documents_1',
  'type' => 'link',
  'relationship' => 'realty_documents_1',
  'source' => 'non-db',
  'vname' => 'LBL_REALTY_DOCUMENTS_1_FROM_DOCUMENTS_TITLE',
);

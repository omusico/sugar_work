<?php
 // created: 2013-02-11 17:14:28
$dictionary['Realty']['fields']['realty_status']['default']='owner';
$dictionary['Realty']['fields']['realty_status']['merge_filter']='disabled';

 ?>
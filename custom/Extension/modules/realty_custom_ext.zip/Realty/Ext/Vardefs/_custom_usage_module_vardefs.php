<?php
// created: 2013-02-12 12:59:27
$dictionary['Realty']['fields']['realty_sugartalk_sms'] = array (
								  'name' => 'realty_sugartalk_sms',
									'type' => 'link',
									'relationship' => 'realty_sugartalk_sms',
									'source'=>'non-db',
									'vname'=>'LBL_SUGARTALK_SMS',
							);
?>

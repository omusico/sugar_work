<?php
 // created: 2013-01-18 13:07:57
$dictionary['Realty']['fields']['sections_exist']['default']='no';
$dictionary['Realty']['fields']['sections_exist']['merge_filter']='disabled';

 ?>
<?php
$dictionary['Realty']['fields']['owner_phone']['type'] = 'function';
$dictionary['Realty']['fields']['owner_phone']['function'] = array('name'=>'sms_phone', 'returns'=>'html', 'include'=>'custom/fieldFormat/sms_phone_fields.php');


?>
<?php
/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$dictionary['Realty']['fields']['realty_contracts'] =
    array (
        'name' => 'realty_contracts',
        'type' => 'link',
        'relationship' => 'realty_contracts',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_CONTRACTS',
    );
<?php
 // created: 2013-01-16 11:36:26
$dictionary['Realty']['fields']['operation_status']['default']='in_rent';
$dictionary['Realty']['fields']['operation_status']['merge_filter']='disabled';

 ?>
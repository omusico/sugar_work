<?php
/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_accounts_buying"] = array (
    'order' => 100,
    'module' => 'Accounts',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_accounts_buying',
    'add_subpanel_data' => 'account_id',
    'title_key' => 'LBL_ACCOUNTS_REALTY_BUYING',
);
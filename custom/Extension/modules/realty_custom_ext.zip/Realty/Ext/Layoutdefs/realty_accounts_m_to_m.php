<?php
/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
//$layout_defs["Realty"]["subpanel_setup"]["realty_accounts_m_to_m"] = array (
//    'order' => 100,
//    'module' => 'Accounts',
//    'subpanel_name' => 'default',
//    'get_subpanel_data' => 'realty_accounts_m_to_m',
//    'add_subpanel_data' => 'realty_id',
//    'title_key' => 'LBL_ACCOUNTS_REALTY',
//);
<?php
/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_contacts_buying"] = array (
    'order' => 100,
    'module' => 'Contacts',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_contacts_buying',
    'add_subpanel_data' => 'contact_id',
    'title_key' => 'LBL_CONTACTS_REALTY_BUYING',
);
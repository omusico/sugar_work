<?php

$layout_defs["Realty"]["subpanel_setup"]["realty_accounts_suitable"] = array (
    'order' => 100,
    'module' => 'Accounts',
    'subpanel_name' => 'ForRealtySuitable',
    'get_subpanel_data' => 'function:getAccountSuitableQuery',
    'generate_select' => true,
    'function_parameters'=>array(
            'import_function_file' => 'custom/application/Ext/Utils/custom_utils.ext.php',
        ),
    'title_key' => 'LBL_REALTY_ACCOUNTS_SUITABLE',
);

<?php

$layout_defs["Realty"]["subpanel_setup"]["realty_accounts_interest"] = array (
    'order' => 100,
    'module' => 'Accounts',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_accounts_interest',
    'add_subpanel_data' => 'realty_id',
    'title_key' => 'LBL_ACCOUNTS_REALTY',
);

<?php
/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_contracts"] = array (
    'order' => 100,
    'module' => 'Contract',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_contracts',
    'add_subpanel_data' => 'contract_id',
    'title_key' => 'LBL_CONTRACTS_REALTY',
);
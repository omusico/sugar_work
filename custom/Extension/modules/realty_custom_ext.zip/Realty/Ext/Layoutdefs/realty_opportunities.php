<?php
/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_opportunities"] = array (
    'order' => 100,
    'module' => 'Opportunities',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_opportunities',
    'add_subpanel_data' => 'opportunity_id',
    'title_key' => 'LBL_REALTY_OPPORTUNITIES',
);
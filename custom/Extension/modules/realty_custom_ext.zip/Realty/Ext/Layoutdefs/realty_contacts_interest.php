<?php

$layout_defs["Realty"]["subpanel_setup"]["realty_contacts_interest"] = array (
    'order' => 100,
    'module' => 'Contacts',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_contacts_interest',
    'add_subpanel_data' => 'realty_id',
    'title_key' => 'LBL_CONTACTS_REALTY',
);

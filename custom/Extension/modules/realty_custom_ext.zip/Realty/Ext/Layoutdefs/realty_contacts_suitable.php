<?php

$layout_defs["Realty"]["subpanel_setup"]["realty_contacts_accounts_suitable"] = array (
    'order' => 100,
    'module' => 'Contacts',
    'subpanel_name' => 'ForRealtySuitable',
    'get_subpanel_data' => 'function:getContactSuitableQuery',
    'generate_select' => true,
    'function_parameters'=>array(
          'import_function_file' => 'custom/application/Ext/Utils/custom_utils.ext.php',  
        ),
     'title_key' => 'LBL_REALTY_CONTACTS_SUITABLE',
     
);

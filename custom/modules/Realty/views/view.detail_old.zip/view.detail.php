<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


require_once('include/MVC/View/views/view.detail.php');

class RealtyViewDetail extends ViewDetail
{
 	public function display()
 	{
 		parent::display();
 	}

    public function getMetaDataFile()
    {
        parent::getMetaDataFile();

        global $current_user;

        if ($this->bean->realty_status == 'realtor' && $current_user->id != $this->bean->assigned_user_id)
        {
            $getMetaDataFile = 'custom/modules/Realty/metadata/detailviewdefsTypeRealtor.php';
        }
        else
        {
            $getMetaDataFile = 'custom/modules/Realty/metadata/detailviewdefs.php';
        }

        return $getMetaDataFile;
    }
}

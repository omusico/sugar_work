<?php

class Not_zero 
{

    function remove_zero(SugarBean $bean, $event, $arguments)
    {
            
        if($bean->number_of_floor == '' || $bean->number_of_floor == 0)
        {
            $bean->number_of_floor = NULL;
        }
        
        if($bean->floor == '' || $bean->floor == 0)
        {
            $bean->floor = NULL;
        }
        
        if($bean->rooms_quantity == '' || $bean->rooms_quantity == 0)
        {
            $bean->rooms_quantity = NULL;
        }
        
        if($bean->living_square == '' || $bean->living_square == 0)
        {
            $bean->living_square = NULL;
        }

        

    }
 
}
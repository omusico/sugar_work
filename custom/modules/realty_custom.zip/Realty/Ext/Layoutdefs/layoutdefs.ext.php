<?php 
 //WARNING: The contents of this file are auto-generated


/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_accounts_rent"] = array (
    'order' => 100,
    'module' => 'Accounts',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_accounts_rent',
    'add_subpanel_data' => 'account_id',
    'title_key' => 'LBL_ACCOUNTS_REALTY_RENT',
);

/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_accounts_buying"] = array (
    'order' => 100,
    'module' => 'Accounts',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_accounts_buying',
    'add_subpanel_data' => 'account_id',
    'title_key' => 'LBL_ACCOUNTS_REALTY_BUYING',
);

/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_opportunities"] = array (
    'order' => 100,
    'module' => 'Opportunities',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_opportunities',
    'add_subpanel_data' => 'opportunity_id',
    'title_key' => 'LBL_REALTY_OPPORTUNITIES',
);

 // created: 2013-07-03 14:00:07
$layout_defs["Realty"]["subpanel_setup"]['realty_documents_1'] = array (
  'order' => 100,
  'module' => 'Documents',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_REALTY_DOCUMENTS_1_FROM_DOCUMENTS_TITLE',
  'get_subpanel_data' => 'realty_documents_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);

 
 // created: 2013-02-12 12:59:27

							$layout_defs['Realty']['subpanel_setup']['realty_sugartalk_sms'] = array (
							  'order' => 250,
							  'module' => 'sugartalk_SMS',
							  'subpanel_name' => 'default',
							  'sort_order' => 'asc',
							  'sort_by' => 'date_entered',
							  'title_key' => 'LBL_SUGARTALK_SMS',
							  'get_subpanel_data' => 'realty_sugartalk_sms',
							  'top_buttons' =>
							  array (
								    array('widget_class' => 'SubPanelSMSButton')
							  ),
							);
							


$layout_defs["Realty"]["subpanel_setup"]["realty_contacts_accounts_suitable"] = array (
    'order' => 100,
    'module' => 'Contacts',
    'subpanel_name' => 'ForRealtySuitable',
    'get_subpanel_data' => 'function:getContactSuitableQuery',
    'generate_select' => true,
    'function_parameters'=>array(
          'import_function_file' => 'custom/application/Ext/Utils/custom_utils.ext.php',  
        ),
     'title_key' => 'LBL_REALTY_CONTACTS_SUITABLE',
     
);


/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_contacts_buying"] = array (
    'order' => 100,
    'module' => 'Contacts',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_contacts_buying',
    'add_subpanel_data' => 'contact_id',
    'title_key' => 'LBL_CONTACTS_REALTY_BUYING',
);

/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_contacts_rent"] = array (
    'order' => 100,
    'module' => 'Contacts',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_contacts_rent',
    'add_subpanel_data' => 'contact_id',
    'title_key' => 'LBL_CONTACTS_REALTY_RENT',
);

/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_meetings"] = array (
    'order' => 2,
    'module' => 'Meetings',
    'subpanel_name' => 'default',
    'sort_order' => 'desc',
    'sort_by' => 'date_entered',
    'title_key' => 'LBL_SUBPANEL_REALTY_MEETINGS_TITLE',
    'get_subpanel_data' => 'realty_meetings', //имя поля link
    'top_buttons' =>
    array (
        0 =>
        array (
            'widget_class' => 'SubPanelTopButtonQuickCreate',
        ),
        1 =>
        array (
            'widget_class' => 'SubPanelTopSelectButton',
            'mode' => 'MultiSelect',
        ),
    ),
);


$layout_defs["Realty"]["subpanel_setup"]["realty_contacts_interest"] = array (
    'order' => 100,
    'module' => 'Contacts',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_contacts_interest',
    'add_subpanel_data' => 'realty_id',
    'title_key' => 'LBL_CONTACTS_REALTY',
);



$layout_defs["Realty"]["subpanel_setup"]["realty_accounts_interest"] = array (
    'order' => 100,
    'module' => 'Accounts',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_accounts_interest',
    'add_subpanel_data' => 'realty_id',
    'title_key' => 'LBL_ACCOUNTS_REALTY',
);


/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
//$layout_defs["Realty"]["subpanel_setup"]["realty_accounts_m_to_m"] = array (
//    'order' => 100,
//    'module' => 'Accounts',
//    'subpanel_name' => 'default',
//    'get_subpanel_data' => 'realty_accounts_m_to_m',
//    'add_subpanel_data' => 'realty_id',
//    'title_key' => 'LBL_ACCOUNTS_REALTY',
//);

/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_tasks"] = array (
    'order' => 2,
    'module' => 'Tasks',
    'subpanel_name' => 'default',
    'sort_order' => 'desc',
    'sort_by' => 'date_entered',
    'title_key' => 'LBL_SUBPANEL_REALTY_TASKS_TITLE',
    'get_subpanel_data' => 'realty_tasks', //имя поля link
    'top_buttons' =>
    array (
        0 =>
        array (
            'widget_class' => 'SubPanelTopButtonQuickCreate',
        ),
        1 =>
        array (
            'widget_class' => 'SubPanelTopSelectButton',
            'mode' => 'MultiSelect',
        ),
    ),
);

/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_contracts"] = array (
    'order' => 100,
    'module' => 'Contract',
    'subpanel_name' => 'default',
    'get_subpanel_data' => 'realty_contracts',
    'add_subpanel_data' => 'contract_id',
    'title_key' => 'LBL_CONTRACTS_REALTY',
);

/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
//$layout_defs["Realty"]["subpanel_setup"]["realty_contacts"] = array (
//    'order' => 100,
//    'module' => 'Contacts',
//    'subpanel_name' => 'default',
//    'get_subpanel_data' => 'realty_contacts',
//    'add_subpanel_data' => 'realty_id',
//    'title_key' => 'LBL_CONTACTS_REALTY',
//);


$layout_defs["Realty"]["subpanel_setup"]["realty_accounts_suitable"] = array (
    'order' => 100,
    'module' => 'Accounts',
    'subpanel_name' => 'ForRealtySuitable',
    'get_subpanel_data' => 'function:getAccountSuitableQuery',
    'generate_select' => true,
    'function_parameters'=>array(
            'import_function_file' => 'custom/application/Ext/Utils/custom_utils.ext.php',
        ),
    'title_key' => 'LBL_REALTY_ACCOUNTS_SUITABLE',
);


/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$layout_defs["Realty"]["subpanel_setup"]["realty_calls"] = array (
    'order' => 2,
    'module' => 'Calls',
    'subpanel_name' => 'default',
    'sort_order' => 'desc',
    'sort_by' => 'date_entered',
    'title_key' => 'LBL_SUBPANEL_REALTY_CALLS_TITLE',
    'get_subpanel_data' => 'realty_calls', //имя поля link
    'top_buttons' =>
    array (
        0 =>
        array (
            'widget_class' => 'SubPanelTopButtonQuickCreate',
        ),
        1 =>
        array (
            'widget_class' => 'SubPanelTopSelectButton',
            'mode' => 'MultiSelect',
        ),
    ),
);
?>
<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2013-02-12 15:23:05
$dictionary['Realty']['fields']['owner_first_name']['audited']=true;
$dictionary['Realty']['fields']['owner_first_name']['merge_filter']='disabled';

 

 // created: 2013-01-18 13:07:57
$dictionary['Realty']['fields']['sections_exist']['default']='no';
$dictionary['Realty']['fields']['sections_exist']['merge_filter']='disabled';

 

/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$dictionary['Realty']['fields']['realty_opportunities'] =
    array (
        'name' => 'realty_opportunities',
        'type' => 'link',
        'relationship' => 'realty_opportunities',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_OPPORTUNITIES',
    );

 // created: 2013-01-16 11:36:26
$dictionary['Realty']['fields']['operation_status']['default']='in_rent';
$dictionary['Realty']['fields']['operation_status']['merge_filter']='disabled';

 

// created: 2013-07-03 14:00:07
$dictionary["Realty"]["fields"]["realty_documents_1"] = array (
  'name' => 'realty_documents_1',
  'type' => 'link',
  'relationship' => 'realty_documents_1',
  'source' => 'non-db',
  'vname' => 'LBL_REALTY_DOCUMENTS_1_FROM_DOCUMENTS_TITLE',
);


 // created: 2013-01-17 13:53:36

 

/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
// Relationship M:M

$dictionary['Realty']['fields']['realty_accounts_m_to_m'] =
    array (
        'name' => 'realty_accounts_m_to_m',
        'type' => 'link',
        'relationship' => 'realty_accounts_m_to_m',
        'source'=>'non-db',
        'vname'=>'LBL_ACCOUNTS_INVESTOR',
    );

$dictionary['Realty']['fields']['realty_accounts_rent'] =
    array (
        'name' => 'realty_accounts_rent',
        'type' => 'link',
        'relationship' => 'realty_accounts_rent',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_ACCOUNTS_RENT',
    );

$dictionary['Realty']['fields']['realty_accounts_interest'] =
    array (
        'name' => 'realty_accounts_interest',
        'type' => 'link',
        'relationship' => 'realty_accounts_interest',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_ACCOUNTS_INTEREST',
    );

$dictionary['Realty']['fields']['realty_accounts_buying'] =
    array (
        'name' => 'realty_accounts_buying',
        'type' => 'link',
        'relationship' => 'realty_accounts_buying',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_ACCOUNTS_BUYING',
    );

// created: 2013-02-12 12:59:27
$dictionary['Realty']['fields']['realty_sugartalk_sms'] = array (
								  'name' => 'realty_sugartalk_sms',
									'type' => 'link',
									'relationship' => 'realty_sugartalk_sms',
									'source'=>'non-db',
									'vname'=>'LBL_SUGARTALK_SMS',
							);



 // created: 2013-02-11 17:14:28
$dictionary['Realty']['fields']['realty_status']['default']='owner';
$dictionary['Realty']['fields']['realty_status']['merge_filter']='disabled';

 

$dictionary['Realty']['fields']['owner_phone']['type'] = 'function';
$dictionary['Realty']['fields']['owner_phone']['function'] = array('name'=>'sms_phone', 'returns'=>'html', 'include'=>'custom/fieldFormat/sms_phone_fields.php');




/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$dictionary['Realty']['fields']['realty_contracts'] =
    array (
        'name' => 'realty_contracts',
        'type' => 'link',
        'relationship' => 'realty_contracts',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_CONTRACTS',
    );

/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
$dictionary['Realty']['fields']['realty_contacts'] =
    array (
        'name' => 'realty_contacts',
        'type' => 'link',
        'relationship' => 'realty_contacts',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_CONTACTS',
    );

$dictionary['Realty']['fields']['realty_contacts_interest'] =
    array (
        'name' => 'realty_contacts_interest',
        'type' => 'link',
        'relationship' => 'realty_contacts_interest',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_CONTACTS_INTEREST',
    );

$dictionary['Realty']['fields']['realty_contacts_rent'] =
    array (
        'name' => 'realty_contacts_rent',
        'type' => 'link',
        'relationship' => 'realty_contacts_rent',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_CONTACTS_RENT',
    );

$dictionary['Realty']['fields']['realty_contacts_buying'] =
    array (
        'name' => 'realty_contacts_buying',
        'type' => 'link',
        'relationship' => 'realty_contacts_buying',
        'source'=>'non-db',
        'vname'=>'LBL_REALTY_CONTACTS_BUYING',
    );
?>
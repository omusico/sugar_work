<?php 
 //WARNING: The contents of this file are auto-generated

 
 // created: 2013-02-12 12:59:27

							$mod_strings['LBL_SUGARTALK_SMS'] = 'SMS';
							

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_REALTY_DOCUMENTS_1_FROM_DOCUMENTS_TITLE'] = 'Документы';

?>
<?php
$module_name = 'Realty';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'type_of_realty' => 
      array (
        'type' => 'enum',
        'label' => 'LBL_TYPE_OF_REALTY',
        'width' => '10%',
        'default' => true,
        'name' => 'type_of_realty',
      ),
      'kind_of_realty' => 
      array (
        'type' => 'enum',
        'label' => 'LBL_KIND_OF_REALTY',
        'width' => '10%',
        'default' => true,
        'name' => 'kind_of_realty',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'owner_last_name' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_OWNER_LAST_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'owner_last_name',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'width' => '10%',
        'default' => true,
      ),
      'created_by' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_CREATED',
        'width' => '10%',
        'default' => true,
        'name' => 'created_by',
      ),
      'rooms_quantity' => 
      array (
        'type' => 'int',
        'label' => 'LBL_ROOMS_QUANTITY',
        'width' => '10%',
        'default' => true,
        'name' => 'rooms_quantity',
      ),
      'square' => 
      array (
        'type' => 'int',
        'label' => 'LBL_SQUARE',
        'width' => '10%',
        'default' => true,
        'name' => 'square',
      ),
      'metro' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_METRO',
        'width' => '10%',
        'default' => true,
        'name' => 'metro',
      ),
      'operation' => 
      array (
        'type' => 'enum',
        'label' => 'LBL_OPERATION',
        'width' => '10%',
        'default' => true,
        'name' => 'operation',
      ),
    ),
    'advanced_search' => 
    array (
      0 => 'name',
      1 => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>

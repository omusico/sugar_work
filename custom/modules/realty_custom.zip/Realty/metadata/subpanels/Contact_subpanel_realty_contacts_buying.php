<?php
// created: 2013-01-16 12:46:32
$subpanel_layout['list_fields'] = array (
  'name' => 
  array (
    'vname' => 'LBL_NAME',
    'widget_class' => 'SubPanelDetailViewLink',
    'width' => '15%',
    'default' => true,
  ),
  'totalcost' => 
  array (
    'vname' => 'LBL_TOTALCOST',
    'width' => '15%',
    'default' => true,
  ),
  'square' => 
  array (
    'vname' => 'LBL_SQUARE',
    'width' => '15%',
    'default' => true,
  ),
  'operation' => 
  array (
    'vname' => 'LBL_OPERATION',
    'width' => '15%',
    'default' => true,
  ),
  'address_street' => 
  array (
    'vname' => 'LBL_ADDRESS_STREET',
    'width' => '15%',
    'default' => true,
  ),
  'date_entered' => 
  array (
    'vname' => 'LBL_DATE_ENTERED',
    'width' => '15%',
    'default' => true,
  ),
  'date_modified' => 
  array (
    'vname' => 'LBL_DATE_MODIFIED',
    'width' => '15%',
    'default' => true,
  ),
  'edit_button' => 
  array (
    'vname' => 'LBL_EDIT_BUTTON',
    'widget_class' => 'SubPanelEditButton',
    'module' => 'Realty',
    'width' => '4%',
    'default' => true,
  ),
  'remove_button' => 
  array (
    'vname' => 'LBL_REMOVE',
    'widget_class' => 'SubPanelRemoveButton',
    'module' => 'Realty',
    'width' => '5%',
    'default' => true,
  ),
);
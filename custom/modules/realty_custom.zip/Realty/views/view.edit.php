<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class RealtyViewEdit extends ViewEdit {

    function UsersViewEdit()
    {
        parent::ViewEdit();
    }

    function display()
    {
        parent::display();

        // Return realty email
        if ($_REQUEST['em_dup'] == 1){

            echo "<script type='text/javascript'>
                function em_dup()
                {
                    $('#Realty0emailAddress0').val('{$_REQUEST['Realty0emailAddress0']}')
                }
                setTimeout(em_dup,10)
            </script>";
        }
    }

    public function getMetaDataFile()
    {
        parent::getMetaDataFile();

        global $current_user;

        if ($this->bean->realty_status == 'realtor' && $current_user->id != $this->bean->assigned_user_id)
        {
            $getMetaDataFile = 'custom/modules/Realty/metadata/editviewdefsTypeRealtor.php';
        }
        else
        {
            $getMetaDataFile = 'custom/modules/Realty/metadata/editviewdefs.php';
        }

        return $getMetaDataFile;
    }
}

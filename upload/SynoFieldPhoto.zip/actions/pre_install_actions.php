<script>
toggleDisplay('displayLog');
</script>
<br />

<?php
echo base64_decode('DQo8dGFibGUgd2lkdGg9IjkwJSIgYm9yZGVyPSIwIiBjZWxsc3BhY2luZz0iMCIgY2VsbHBhZGRpbmc9IjUiPg0KICAgIDx0cj4NCiAgICAgICAgPHRkPjxpbWcgc3JjPSJodHRwOi8vd3d3LmNybS1mcmFuY2UuY29tL0xvZ28tU3lub2xpYS5qcGciIHdpZHRoPSIzNDAiIGhlaWdodD0iMTE2IiBhbHQ9IkxvZ28gU3lub2xpYSIgLz48L3RkPg0KICAgIDwvdHI+DQogICAgPHRyPg0KICAgICAgICA8dGQgYWxpZ249ImxlZnQiIHZhbGlnbj0idG9wIj4NCiAgICAgICAgICAgIDxoMT5TeW5vRmllbGRQaG90byDQvtGCIFN5bm9saWE8L2gxPg0KICAgICAgICAgICAgPHA+DQogICAgICAgICAgICAJ0KHQv9Cw0YHQuNCx0L4g0LfQsCDQuNGB0L/QvtC70YzQt9C+0LLQsNC90LjQtSDRgNCw0LfRgNCw0LHQvtGC0L7QuiBTWU5PTElBLjxiciAvPg0KICAgICAgICAgICAgPC9wPg0KICAgICAgICA8L3RkPg0KICAgIDwvdHI+DQogICAgPHRyPg0KICAgICAgICA8dGQgYWxpZ249ImNlbnRlciI+DQogICAgICAgICAgICA8YSBocmVmPSJodHRwOi8vd3d3LnN5bm9saWEuY29tIj53d3cuc3lub2xpYS5jb208L2E+PGJyIC8+DQogICAgICAgICAgICDQoNGD0YHQuNGE0LjQutCw0YbQuNGPINC80L7QtNGD0LvRjyAtIDxhIGhyZWY9Imh0dHA6Ly9zdWdhcnRhbGsucnUiIHRhcmdldD0iX2JsYW5rIiBzdHlsZT0iZm9udC1zaXplOjEzcHg7Ij5zdWdhcnRhbGsucnU8L2E+DQogICAgICAgIDwvdGQ+DQogICAgPC90cj4NCjwvdGFibGU+DQo8YnIgLz4=');

/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by SYNOLIA are Copyright (C) 2004-2010 SYNOLIA. You do not
 * have the right to remove SYNOLIA copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact SYNOLIA at contact@synolia.com
***********************************************************************************/
/**********************************************************************************
 * The Original Code is:    SYNOFIELDPHOTO by SYNOLIA
 *                          www.synolia.com - sugar@synolia.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/
?>
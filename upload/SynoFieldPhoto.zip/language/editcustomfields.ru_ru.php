<?php
$mod_strings['HEIGHT'] = 'Максимальная высота';
$mod_strings['WIDTH'] = 'Максимальная ширина';
$mod_strings['STYLE'] = 'CSS стиль';
$mod_strings['PHOTO_IS_BY_DEFAULT'] = 'Для изображения по умолчанию, разместите данное изображение в custom/SynoFieldPhoto/phpThumb/images/defaults/. Имя изображения должно иметь следующий вид: Modulenamefieldname_c.jpg';
$mod_strings['PHOTO_IS_NOT_REPORTABLE'] = 'Поля с изображениями не доступны в отчетах';
$mod_strings['PHOTO_IS_NOT_IMPORTABLE'] = 'Поля с изображениями не импортируемые';
$mod_strings['PHOTO_IS_NOT_MERGEABLE'] = 'Поля с изображениями не могут использоваться для объединения дубликатов';
?>
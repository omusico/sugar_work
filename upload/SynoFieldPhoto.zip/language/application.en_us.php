<?php
$app_strings['ONLY_EXISTING_RECORD'] = 'You can only set Pictures on an existing record.';
$app_strings['NO_PICTURE_AVAILABLE'] = 'No Picture Available';
$app_strings['LBL_SEARCH_WITHOUT_PICTURE'] = 'Without Picture';
$app_strings['LBL_SEARCH_WITH_PICTURE'] = 'With Picture';
?>
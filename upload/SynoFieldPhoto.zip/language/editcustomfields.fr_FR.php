<?php 
$mod_strings['HEIGHT'] = 'Hauteur max';
$mod_strings['WIDTH'] = 'Largeur max';
$mod_strings['STYLE'] = 'Style CSS';
$mod_strings['PHOTO_IS_BY_DEFAULT'] = 'L&#39;image par défaut doit être uploadée dans custom/SynoFieldPhoto/phpThumb/images/defaults/ et doit avoir pour nom Nomdumodulenomduchamp_c.jpg';
$mod_strings['PHOTO_IS_NOT_REPORTABLE'] = 'Les champs de type Photo ne sont pas utilisables dans les Rapports';
$mod_strings['PHOTO_IS_NOT_IMPORTABLE'] = 'Les champs de type Photo ne sont pas importables';
$mod_strings['PHOTO_IS_NOT_MERGEABLE'] = 'Les champs de type Photo ne sont pas fusionnables';
?>
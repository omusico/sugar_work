<?php
$app_strings['ONLY_EXISTING_RECORD'] = 'Вы можете только установить изображение для существующей записи.';
$app_strings['NO_PICTURE_AVAILABLE'] = 'Нет доступного изображения';
$app_strings['LBL_SEARCH_WITHOUT_PICTURE'] = 'Без изображения';
$app_strings['LBL_SEARCH_WITH_PICTURE'] = 'С изображением';
?>
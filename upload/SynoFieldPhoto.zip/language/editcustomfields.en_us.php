<?php
$mod_strings['HEIGHT'] = 'Max Height';
$mod_strings['WIDTH'] = 'Max Weight';
$mod_strings['STYLE'] = 'CSS Style';
$mod_strings['PHOTO_IS_BY_DEFAULT'] = 'If you wnt to have a default picture upload it in custom/SynoFieldPhoto/phpThumb/images/defaults/. The name of the picture must be Modulenamefieldname_c.jpg';
$mod_strings['PHOTO_IS_NOT_REPORTABLE'] = 'Photo fields are not available in Reports';
$mod_strings['PHOTO_IS_NOT_IMPORTABLE'] = 'Photo fields are not importable';
$mod_strings['PHOTO_IS_NOT_MERGEABLE'] = 'Photo fields can not be merged';
?>
<?php
$app_strings['ONLY_EXISTING_RECORD'] = 'Vous ne pouvez mettre de Photo que sur un enregistrement existant.';
$app_strings['NO_PICTURE_AVAILABLE'] = 'Pas de Photo';
$app_strings['LBL_SEARCH_WITHOUT_PICTURE'] = 'Sans Photo';
$app_strings['LBL_SEARCH_WITH_PICTURE'] = 'Avec Photo';
?>
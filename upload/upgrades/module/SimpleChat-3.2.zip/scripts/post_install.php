<?php
if(!defined('sugarEntry'))define('sugarEntry', true);

function post_install() {
	global $current_user;
	global $log;
	global $db;

	global $unzip_dir;
	global $sugar_config;
	$db = &DBManagerFactory::getInstance();

$is_mssql= false;
if (strtolower($db->dbType)=='mssql') {
	$is_mssql= true;
}

if (strtolower($_POST['mode']) == 'install') {

 if ($is_mssql) { //start MSSQL

 	$qu = "
	IF NOT EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	  CREATE TABLE messages (
	    id int IDENTITY(1,1) NOT NULL,
	    [user] varchar(65) default NULL,
	    msg text NOT NULL,
	    time int NOT NULL,
	    foruser varchar(65) NOT NULL,
	    del tinyint NOT NULL default '0',
	    PRIMARY KEY  (id)
	  ) ";
	  $db->query($qu);

	  $qu = "
	IF NOT EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages_history') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	  CREATE TABLE messages_history (
	    id int NOT NULL default '0',
	    [user] varchar(65) default NULL,
	    msg text NOT NULL,
	    time int NOT NULL,
	    foruser varchar(65) NOT NULL,
	    del tinyint NOT NULL default '0',
	    PRIMARY KEY (id)
	  ) ";
	  $db->query($qu);

	  $qu = "
	IF NOT EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages_online') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	  CREATE TABLE messages_online (
	    usr_id char(36) DEFAULT NULL,
	    usr_name varchar(64) NOT NULL,
	    otop varchar(20) DEFAULT NULL,
	    oleft varchar(20) DEFAULT NULL,
	    rtime int NOT NULL,
	    collapsed varchar(20) DEFAULT 'false'
	  ) ";
	  $db->query($qu);

	  $qu = "
	IF NOT EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages_config') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	  CREATE TABLE messages_config (
	    id varchar(36) NOT NULL,
	    disable_chat tinyint NOT NULL default '0',
	    skin varchar(50) DEFAULT NULL,
        PRIMARY KEY (id)
	  ) ";
	  $db->query($qu);

	  $qu = "
	  INSERT INTO messages_config (id, disable_chat, skin) VALUES ('main', 0, 'white');";
	  $db->query($qu);

 } //end MSSQL
 else {
 	$qu = "
	  CREATE TABLE IF NOT EXISTS messages (
	    id int(7) NOT NULL auto_increment,
	    user varchar(65) default NULL,
	    msg text NOT NULL,
	    time int(9) NOT NULL,
	    foruser varchar(65) NOT NULL,
	    del tinyint(1) NOT NULL default '0',
	    PRIMARY KEY  (id)
	  ) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ; ";
	  $db->query($qu);

	  $qu = "
	  CREATE TABLE IF NOT EXISTS messages_history (
	    id int(7) NOT NULL default '0',
	    user varchar(65) default NULL,
	    msg text NOT NULL,
	    time int(9) NOT NULL,
	    foruser varchar(65) NOT NULL,
	    del tinyint(1) NOT NULL default '0',
	    PRIMARY KEY  (id)
	  ) ENGINE=MyISAM DEFAULT CHARSET=utf8; ";
	  $db->query($qu);

	  $qu = "
	  CREATE TABLE IF NOT EXISTS messages_online (
	    usr_id char(36) DEFAULT NULL,
	    usr_name varchar(64) NOT NULL,
	    otop varchar(20) DEFAULT NULL,
	    oleft varchar(20) DEFAULT NULL,
	    rtime int(11) NOT NULL,
	    collapsed varchar(20) DEFAULT 'false'
	  ) ENGINE=MyISAM DEFAULT CHARSET=utf8;	";
	  $db->query($qu);

	  $qu = "
	  CREATE TABLE IF NOT EXISTS messages_config (
	    id varchar(36) NOT NULL,
	    disable_chat tinyint(1) NOT NULL default '0',
	    skin varchar(50) DEFAULT NULL,
        PRIMARY KEY (id)
	  ) ENGINE=MyISAM DEFAULT CHARSET=utf8;	";
	  $db->query($qu);

	  $qu = "
	  INSERT INTO messages_config (id, disable_chat, skin) VALUES ('main', 0, 'white');";
	  $db->query($qu);
 }

}
else {//uninstall

echo '<script type="text/javascript">
    oEl= document.getElementById("beforeChat");
    oEl.style.display="none";
</script>';

	if ($is_mssql) { //start MSSQL

		$un="
		IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages_online') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
		DROP TABLE messages_online";
		$db->query($un);

		if ($_POST['remove_tables']=='true') {
		  $un="
		  IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
		  DROP TABLE messages";
		  $db->query($un);

		  $un="
          IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages_history') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
		  DROP TABLE messages_history";
		  $db->query($un);

		  $un="
          IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages_config') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
		  DROP TABLE messages_config";
		  $db->query($un);
		}

	} //end MSSQL
	else {
	 	$un="DROP TABLE IF EXISTS messages_online";
		$db->query($un);

		if ($_POST['remove_tables']=='true') {
		  $un="DROP TABLE IF EXISTS messages, messages_history, messages_config";
		  $db->query($un);
		}
	}

}//end uninstall

  require_once('ModuleInstall/ModuleInstaller.php');
  $mi = new ModuleInstaller();
  $mi->rebuild_all();

}
?>

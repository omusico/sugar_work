<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* Simple Chat is a chat for SugarCRM developed by Letrium, Ltd.
* Copyright (C) 2006 - 2013 Letrium Ltd.
*
* This program is free software; you can redistribute it and/or modify it under
* the terms of the GNU General Public License version 3 as published by the
* Free Software Foundation with the addition of the following permission added
* to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
* IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
* OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or FITNESS
* FOR A PARTICULAR PURPOSE. See  the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if  not, see http://www.gnu.org/licenses or write to the Free
* Software Foundation, Inc., 51  Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*
* You can contact Letrium Ltd. at email address crm@letrium.com.
*
* SimpleChat version 3.1, Copyright (C) Letrium Ltd., Taras Machyshyn.
*
* In accordance with Section 7(b) of the GNU General Public License version 3,
* these Appropriate Legal Notices must retain the display of the "Letrium" label.
*
*For more information on how to apply and follow the GNU GPL, see http://www.gnu.org/licenses.
********************************************************************************/

global $db, $current_user;
if(empty($db)) {
	$db = DBManagerFactory::getInstance();
}

require_once('modules/let_Chat/helper.php');
$helper= new chatHelper();

$display_num = $helper->display_num;
$user_timeout = $helper->user_timeout; // seconds
$prefix = 'messages';  //deprecated
$timestamp=time();
$time= time();

/*$q = "SELECT otop, oleft FROM ".$prefix."_online WHERE usr_id='".$current_user->id."' limit 0,1" ;
$result = $db->query($q);
while (($message = $db->fetchByAssoc($result)) != null) {
	$otop =  $message['otop'];
  	$oleft =  $message['oleft'];
    $collapsed=$message['collapsed'];
} */

$q="DELETE FROM messages_online WHERE usr_id='".$current_user->id."' OR ($timestamp-rtime)>$user_timeout";
$db->query($q);

if (!empty($_REQUEST['collapsed'])) $_SESSION['collapsed']=$_REQUEST['collapsed'];

/*if (($_REQUEST['top']=='0px') && ($_REQUEST['left']=='0px'))
{
  $_REQUEST['top']=$otop;
  $_REQUEST['left']=$oleft;
}
else
{
  $otop=$_REQUEST['top'];
  $oleft=$_REQUEST['left'];
}       */
$q="INSERT INTO messages_online (usr_id, usr_name, rtime, collapsed)  VALUES('".$current_user->id."','".$current_user->user_name."',$timestamp, '".$_REQUEST['collapsed']."')";
$db->query($q);

if(!$_REQUEST['time']){
	$_REQUEST['time'] = 0;
}
$myTmp=mktime(5,0,0,date('m'),date('d'),date('Y'));

//history
$history_query = "SELECT * FROM messages WHERE time<".$myTmp." ORDER BY id ASC" ;
$history_query= $helper->escapeSQL($history_query); //Taras 2012-12-21
$history_result = $db->query($history_query);
while (($history = $db->fetchByAssoc($history_result)) != null) {
   $h_query="INSERT INTO messages_history (id, user, msg, time, foruser, del)
        VALUES ('".$history['id']."',
         '".$history['user']."',
         '".$db->quote($history['msg'])."',
          '".$history['time']."',
          '".$history['foruser']."',
          '".$history['del']."'
    ); ";
   $db->query($h_query);

   $del= "DELETE FROM messages WHERE id = ".$history['id'];
   $res=$db->limitQuery($del, 0, 1);
}
//end history
$data = array();
  /* $data[]['top'] =  $otop;
  	$data[]['left'] =  $oleft;*/

  switch($_GET['task']) {
  	 case 'delete_history':

		$q="UPDATE messages SET del=1 WHERE foruser='".$current_user->user_name."'";
		$db->query($q);
  	 break;

    case 'add':

	$name = htmlspecialchars(trim($_REQUEST['nickname']));
	$message = $db->quote(trim($_REQUEST['message']));
	$for_user = htmlspecialchars(trim($_REQUEST['for_user']));

   	$q = "INSERT INTO messages (user,msg, time, foruser)
			VALUES ('$name','$message',".$time.",'$for_user')";
	$q= $helper->escapeSQL($q); //Taras 2012-12-21
	$db->query($q);

	//TARAS 2012-12-20: MSSQL fix
	/*
	$q = "SELECT rez1.* FROM (SELECT id,user as nickname,msg as message,time,foruser
						 FROM messages
						 WHERE id>".$_REQUEST['time']." AND ((foruser = 'all') OR (foruser = '".$current_user->user_name."')
						 	OR user='".$current_user->user_name."') AND time>=".$myTmp."  ORDER BY id DESC)
					AS rez1,
					messages WHERE rez1.id=messages.id ORDER BY id ASC";
	*/
	$q = "SELECT id, id as sortid, user as nickname, msg as message, time, foruser
						 FROM messages
						 WHERE id>".$_REQUEST['time']." AND ((foruser = 'all') OR (foruser = '".$current_user->user_name."')
						 	OR user='".$current_user->user_name."') AND time>=".$myTmp."
						 ORDER BY sortid ASC";
    $q= $helper->escapeSQL($q); //Taras 2012-12-21
	$result = $db->limitQuery($q, 0, $display_num);
	while (($message = $db->fetchByAssoc($result)) != null) {
			$message['msg'] = htmlspecialchars(stripslashes($message['msg']));
			$data[]=$message;
	}

    break;

    case 'view':
//letrium tanya

	//TARAS 2012-12-20: MSSQL fix
	/*$q = "SELECT rez1.* FROM (SELECT id,user as nickname,msg as message,time,foruser
						 FROM messages
						 WHERE id>".$_REQUEST['time']." AND foruser = 'all' AND time>=".$myTmp."  ORDER BY id DESC)
						  AS rez1,messages  WHERE rez1.id=messages.id ORDER BY id ASC";*/

	$q = "SELECT id, id as sortid, user as nickname, msg as message, time, foruser
						 FROM messages
						 WHERE id>".$_REQUEST['time']." AND foruser = 'all' AND time>=".$myTmp."
						 ORDER BY sortid ASC";
	$q= $helper->escapeSQL($q); //Taras 2012-12-21
	$result = $db->limitQuery($q, 0, $display_num);

	while (($message = $db->fetchByAssoc($result)) != null) {
			$message['msg'] = htmlspecialchars(stripslashes($message['msg']));
			$data[]=$message;
	}

	$q = "SELECT user_name as name FROM users WHERE deleted = 0";
	$users_res = $db->query($q);
	while ($user = $db->fetchByAssoc($users_res))
	{
		/*$q = "SELECT rez1.* FROM (SELECT id,user as nickname,msg as message,time,foruser
						 FROM messages
						 WHERE id>".$_REQUEST['time']." AND
						 	((foruser = '".$current_user->user_name."' AND user='".$user['name']."') OR
						 	(user = '".$current_user->user_name."' AND foruser='".$user['name']."'))
						 	 AND time>=".$myTmp."  ORDER BY id DESC limit ".$display_num." )
						  AS rez1,messages  WHERE rez1.id=messages.id ORDER BY id ASC"; */

		//TARAS 2012-12-20: MSSQL fix
		$q = "SELECT id, id as sortid, user as nickname,msg as message,time,foruser
						 FROM messages
						 WHERE id>".$_REQUEST['time']." AND
						 	((foruser = '".$current_user->user_name."' AND user='".$user['name']."') OR
						 	(user = '".$current_user->user_name."' AND foruser='".$user['name']."'))
						 	 AND time>=".$myTmp."
							 ORDER BY sortid ASC";
		$q= $helper->escapeSQL($q); //Taras 2012-12-21
		$result = $db->limitQuery($q, 0, $display_num);

		while (($message = $db->fetchByAssoc($result)) != null) {
				$message['msg'] = htmlspecialchars(stripslashes($message['msg']));
				$data[]=$message;
		}
	}


	/*
	//original
	$q = "SELECT rez1.* FROM (SELECT id,user as nickname,msg as message,time,foruser
						 FROM messages
						 WHERE id>".$_REQUEST['time']." AND ((foruser = 'all') OR (foruser = '".$current_user->user_name."')
						 	OR user='".$current_user->user_name."') AND time>=".$myTmp."  ORDER BY id DESC limit ".$display_num." )
						  AS rez1,messages  WHERE rez1.id=messages.id ORDER BY id ASC";


	$result = $db->limitQuery($q, 0, $display_num);
	while (($message = $db->fetchByAssoc($result)) != null) {
			$message['msg'] = htmlspecialchars(stripslashes($message['msg']));
			$data[]=$message;
	}
	*/
   //letrium end
    break;
  }

if ($helper->is_mssql()) {
	$q = "SELECT usr_name FROM messages_online WHERE usr_id <>'".$current_user->id."' ORDER BY usr_name ASC" ;
}
else {
	$q = "SELECT usr_name FROM messages_online WHERE usr_id <>'".$current_user->id."' GROUP BY usr_id ORDER BY usr_name ASC" ;
}
$result = $db->query($q);
while (($message = $db->fetchByAssoc($result)) != null) {
	$data[] =  $message;
}

if (empty($data)) {
	$data[]=array('status'=>'success');
}                                      

  require_once('modules/let_Chat/JSON.php');
  $json = new Services_JSON();
  $out = $json->encode($data);
  ob_clean();
  print $out;
  exit;
?>

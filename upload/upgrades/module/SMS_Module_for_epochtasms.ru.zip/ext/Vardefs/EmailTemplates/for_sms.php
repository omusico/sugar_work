<?php

$dictionary["EmailTemplate"]["fields"]["sms_only"] = array (
	'name' => 'sms_only',
	'vname' => 'LBL_SMS_ONLY',
	'type' => 'bool',
	'required' => true,
	'reportable'=>false,
	'default' => false,
	'comment' => 'Distinguishes the template from the one for Emails'
);
?>

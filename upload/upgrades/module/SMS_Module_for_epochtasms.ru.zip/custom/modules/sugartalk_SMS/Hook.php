<?php
class Hook {

   function connect($bean, $mapping)
   {
       echo '<script type="text/javascript" language="JavaScript" src="modules/Administration/sugartalk_smsPhone/javascript/smsPhone.js"></script>';
       echo '<script type="text/javascript" language="JavaScript" src="modules/Administration/sugartalk_smsPhone/javascript/jquery.jmpopups-0.5.1.js"></script>';
   }
}


?>

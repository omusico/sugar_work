<?php
$job_strings[] = 'runMassSMSCampaign';
$job_strings[] = 'sendSmsReminders';

function runMassSMSCampaign() {

	$GLOBALS['log']->debug('Called:runMassSMSCampaign');

	if (!class_exists('DBManagerFactory')){
		require('include/database/DBManagerFactory.php');
	}

	global $beanList;
	global $beanFiles;
	require("config.php");
	require('include/modules.php');
	if(!class_exists('AclController')) {
		require('modules/ACL/ACLController.php');
	}

	require('modules/EmailMan/SMSManDelivery.php');
	return true;
}

function sendSmsReminders(){
    $GLOBALS['log']->info('----->Scheduler fired job of type sendEmailReminders()');
    require_once("modules/Activities/SmsReminder.php");
    $reminder = new SmsReminder();
    return $reminder->process();
}

?>

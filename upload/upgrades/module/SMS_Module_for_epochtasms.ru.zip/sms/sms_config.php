<?php
$sms_config["sms_instance_id"] = "";
$sms_config["uses_sms_template"] = "";
$sms_config["sugartalk_url"] = "";
$sms_config["sender"] = "";
$sms_config["domain_name"] = "";
$sms_config["default_country_code"] = "";
$sms_config["local_prefix"] = "";
?>

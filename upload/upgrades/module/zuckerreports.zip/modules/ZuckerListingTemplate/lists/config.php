<?php
$zuckerreports_lists = array(
	
	"Contacts" => array(
		"Contacts_Emails.html" => "Contacts (Email only)",
		"Contacts_ListView.html" => "Contacts (ListView)",
	),
	"Leads" => array(
		"Leads_Emails.html" => "Leads (Email only)",
		"Leads_ListView.html" => "Leads (ListView)",
	),	
	"Cases" => array(
		"Cases_ListView.html" => "Cases (ListView)",
	),		
	"Accounts" => array(
		"Accounts_ListView.html" => "Accounts (ListView)",
	),		
	"Opportunities" => array(
		"Opportunities_ListView.html" => "Opportunities (ListView)",
	),		
);


?>
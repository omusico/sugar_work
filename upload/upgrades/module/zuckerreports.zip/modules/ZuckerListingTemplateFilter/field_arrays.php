<?php
$fields_array['ListingTemplateFilter'] = array (
	'column_fields' => array(
		"id"
		,"listing_template_id"
		,"module_name"
		,"field_name"
		,"comparator"
		,"value_type"
		,"value"
		,"date_entered"
		,"date_modified"
		,"created_by"
		,"modified_user_id"	
	),
    'list_fields' =>  array(
		"id"
		,"listing_template_id"
		,"module_name"
		,"field_name"
		,"comparator"
		,"value_type"
		,"value"
		,"date_entered"
		,"date_modified"
		,"created_by"
		,"modified_user_id"	
	),
    'required_fields' =>  array(),
);
?>

<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $app_strings, $current_language;

$dashletMeta['ZuckerReportDisplayDashlet'] = array('title'       => 'LBL_TITLE', // array index in language pack 
                                      'description' => 'LBL_DESCRIPTION', // array index in language pack 
                                      'category'    => 'Module Views');
?>

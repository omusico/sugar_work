<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletStrings['ZuckerReportContainerDashlet'] = array('LBL_TITLE'            => 'ZuckerReports Archive',
                                         'LBL_DESCRIPTION'      => 'Display current category content within a Dashlet',
                                         'LBL_CONFIGURE_TITLE'  => 'Title',
                                         'LBL_CONFIGURE_CONTAINER' => 'Category',
                                         'LBL_CONFIGURE_COUNT' => 'max. row count',

);
?> 

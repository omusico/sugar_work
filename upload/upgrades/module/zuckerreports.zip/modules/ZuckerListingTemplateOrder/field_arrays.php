<?php
$fields_array['ListingTemplateOrder'] = array (
	'column_fields' => array(
		"id"
		,"listing_template_id"
		,"module_name"
		,"field_name"
		,"order_type"
		,"date_entered"
		,"date_modified"
		,"created_by"
		,"modified_user_id"	
	),
        'list_fields' =>  array(
		"id"
		,"listing_template_id"
		,"module_name"
		,"field_name"
		,"order_type"
		,"date_entered"
		,"date_modified"
		,"created_by"
		,"modified_user_id"	
	),
    	'required_fields' =>  array('name'=>1),
);
?>

<?

$app_list_strings['moduleList']['ZuckerReports']='ZuckerReports';
?>

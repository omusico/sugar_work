<?PHP
$mod_strings['LBL_FIELDSACL_ADMIN'] = 'Field Level Access';
$mod_strings['LBL_FIELDSACL_ADMIN_DESCRIPTION'] = 'Manage Field Level Access';
$mod_strings['LBL_FIELDSACL_ADMIN_TITLE'] = 'Field Level Access';
$mod_strings['FIELDSACL_ADMIN_TITLE'] = 'Field Level Access';
$mod_strings['FIELDSACL_ADMIN_DESC'] = 'Manage Field Level Access';
?>

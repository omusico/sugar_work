<?PHP
$mod_strings['LBL_FIELDSACL_ADMIN'] = 'Уровень доступа к полям';
$mod_strings['LBL_FIELDSACL_ADMIN_DESCRIPTION'] = 'Настроить уровень доступа к полям';
$mod_strings['LBL_FIELDSACL_ADMIN_TITLE'] = 'Уровень доступа к полям';
$mod_strings['FIELDSACL_ADMIN_TITLE'] = 'Уровень доступа к полям';
$mod_strings['FIELDSACL_ADMIN_DESC'] = 'Настроить уровень доступа к полям';
?>

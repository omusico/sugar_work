$( document ).ready(function() {
    
    $('#create_link').html('Действия');
    $('#create_link').click(function () {return false;});
    
});
<?php
$app_list_strings['moduleList']['acl_fields'] = 'Поля';
$app_list_strings['fields_access_list'] = array(
						'' => 'Не установленно',
						0 => 'Полный доступ',
						1 => 'Только просмотр',
						2 => 'Нет доступа',
						);

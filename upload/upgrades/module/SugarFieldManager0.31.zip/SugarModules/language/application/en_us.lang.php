<?php
$app_list_strings['moduleList']['acl_fields'] = 'Fields';
$app_list_strings['fields_access_list'] = array(
						'' => 'Not Set',
						0 => 'All',
						1 => 'Read Only',
						2 => 'No Access',
						);

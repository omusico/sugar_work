<?php
// dummy file to allow /index.php?module=GoogleSync&action=Test&record=
?>
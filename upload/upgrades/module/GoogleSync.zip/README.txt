FEATURES:
GoogleCalSync automaticly adds Calls, ProjectTasks and Meetings to your Google-Calendar

REQUIREMENTS:
 - ZendGData Library (included, will be automaticly installed)
 - PHP5 (required by ZendGData Library)
 - SugarCRM 4.5.1 (4.5.0 doesn't native support PHP5)


INSTALLATION:

1. Download GoogleCalSync from http://www.sugarforge.org/projects/googlecalsync/

2. Login as Administrator to your SugarCRM

3. Use Module-Loader to upload and install GoogleCalSync

4. Use the Studio to add CustomFields to the "Users"-Modul
    - To access the Studio for Users open: http://host/sugar/index.php?action=wizard&module=Studio&wizard=SelectModuleWizard&option=Users

5. Add the following to CustomFields:
    - First:  "googleaccount" as Text
    - Second: "googlepass"    as Text

6. Edit "My Account" and fill in these new 2 fields
    - e.g.: Google-Account:  firstname.lastname@gmail.com
            Google-Password: mySecret4u

7. Ready.


USAGE:

When ever a Meeting, ProjectTask or Call with you as attendee gets saved,
it will apper in your Google-Calendar.
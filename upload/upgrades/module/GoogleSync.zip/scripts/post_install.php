<?php

if(!defined('sugarEntry'))define('sugarEntry', true);

function post_install() {

   require_once('include/utils.php');

   check_logic_hook_file("Meetings", "before_save", array(1, "save_googlecal",  
      "modules/GoogleSync/Hooks.php", "GoogleSyncHooks", "onSave"));
   check_logic_hook_file("Meetings", "after_delete", array(2, "delete_googlecal",  
      "modules/GoogleSync/Hooks.php", "GoogleSyncHooks", "onAfterDelete"));
   check_logic_hook_file("Meetings", "after_restore", array(3, "restore_googlecal",  
      "modules/GoogleSync/Hooks.php", "GoogleSyncHooks", "onAfterRestore"));
      
   check_logic_hook_file("Calls", "before_save", array(4, "save_googlecal",  
      "modules/GoogleSync/Hooks.php", "GoogleSyncHooks", "onSave"));
   check_logic_hook_file("Calls", "after_delete", array(5, "delete_googlecal",  
      "modules/GoogleSync/Hooks.php", "GoogleSyncHooks", "onAfterDelete"));
   check_logic_hook_file("Calls", "after_restore", array(6, "restore_googlecal",  
      "modules/GoogleSync/Hooks.php", "GoogleSyncHooks", "onAfterRestore"));
      
   check_logic_hook_file("Tasks", "before_save", array(7, "save_googlecal",  
      "modules/GoogleSync/Hooks.php", "GoogleSyncHooks", "onSave"));
   check_logic_hook_file("Tasks", "after_delete", array(8, "delete_googlecal",  
      "modules/GoogleSync/Hooks.php", "GoogleSyncHooks", "onAfterDelete"));
   check_logic_hook_file("Tasks", "after_restore", array(9, "restore_googlecal",  
      "modules/GoogleSync/Hooks.php", "GoogleSyncHooks", "onAfterRestore"));
    
    echo "Hooks erfolgreich installiert.<br/>";
    
    post_install_readme();
}

function post_install_readme() {
    echo "<br><pre>";
    readfile(dirname(__FILE__)."/../README.txt");
    echo "</pre>";
}

?>

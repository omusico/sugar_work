<?php

// function fired before ununstall module run
function pre_uninstall()
{
	$GLOBALS['log']->info('Start OfficeReports pre uninstall functions');

	$current_level = error_reporting();
	error_reporting(0);// Remove all possible warning
	get_html('goodbye'); // get text for after uninstall text

	$GLOBALS['log']->info('End OfficeReports pre uninstall functions');
}


function get_html($name_html = 'goodbye')
{
	global $current_language;
	global $goodbye_html;

	$goodbye_file = false;
	$content = '';

	if (is_file('modules/OfficeReportsMerge/html/language/' . $current_language . '.' . $name_html . '.html'))
	{
		$goodbye_file = 'modules/OfficeReportsMerge/html/language/' . $current_language . '.' . $name_html . '.html';
	}
	elseif (is_file('modules/OfficeReportsMerge/language/en_us.' . $name_html . '.html'))
	{
		$goodbye_file = 'modules/OfficeReportsMerge/language/en_us.' . $name_html . '.html';
	}

	if ($goodbye_file)
		$content = file_get_contents($goodbye_file);

	$goodbye_html = $content;
}

<?php

// function fired after install module or after uninstall module
function post_install()
{
	if ($_REQUEST['mode'] == 'Install')
	{
		// install
		$GLOBALS['log']->info('Start OfficeReports post install functions');

		repair_and_rebuild(); // auto repair and rebuild all changes
		officeReportSetConfig(); // rebuild sugar config with new office reports settings
		print_html('welcome'); // print welcome text

		$GLOBALS['log']->info('End OfficeReports post install functions');
	}
	else
	{
		// uninstall
		$GLOBALS['log']->info('Start OfficeReports post uninstall functions');

		officeReportDelConfig(); // delete office reports settings from sugar config
		print_goodbye(); // print goodbye text

		$GLOBALS['log']->info('End OfficeReports post uninstall functions');
	}
}

function officeReportSetConfig()
{
	require_once 'custom/include/OfficeReportsMerge/Reports/Utils.php';
	Reports_Utils::set_config(array());
}

function officeReportDelConfig()
{
	require_once 'custom/include/OfficeReportsMerge/Reports/Utils.php';
	Reports_Utils::del_config();
}

function repair_and_rebuild()
{
	// it's function auto repair and rebuild all changes, without user intervention
	require_once('modules/Administration/QuickRepairAndRebuild.php');

	// changed function
	$repair_modules = array (
		'OfficeReportsMerge',
		'OfficeReportsHistory',
		'OfficeReportsVariables',
	);
	// repair action
	$repair_actions = array (
		'clearTpls',
		'clearJsFiles',
		'clearVardefs',
		'clearJsLangFiles',
		'rebuildExtensions',
		'clearLangFiles',
		'repairDatabase',
		'clearThemeCache',
	);

	$RepairAndClear = new RepairAndClear();
	$RepairAndClear->repairAndClearAll($repair_actions, $repair_modules, $autoexecute = true, $show_output = false);

	// repair ACL for new module
	ACLAction::addActions('OfficeReportsMerge');
	ACLAction::addActions('OfficeReportsHistory');

	return TRUE;
}


function print_html($name_html = 'welcome')
{
	global $current_language;

	$welcome_file = false;
	$content = '';

	if (is_file('modules/OfficeReportsMerge/html/language/' . $current_language . '.' . $name_html . '.html'))
	{
		$welcome_file = 'modules/OfficeReportsMerge/html/language/' . $current_language . '.' . $name_html . '.html';
	}
	elseif (is_file('modules/OfficeReportsMerge/html/language/en_us.' . $name_html . '.html'))
	{
		$welcome_file = 'modules/OfficeReportsMerge/html/language/en_us.' . $name_html . '.html';
	}

	if ($welcome_file)
		$content = file_get_contents($welcome_file);

	echo $content;
}

function print_goodbye()
{
	// the module is already deleted
	// give goodbye html text from global var
	global $goodbye_html;
	echo $goodbye_html;
}

?>

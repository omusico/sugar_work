editArea.add_lang("en",{
charmap_but: "Visual keyboard",
charmap_title: "Visual keyboard",
charmap_choose_block: "select language block",
charmap_insert:"insert this character"
});

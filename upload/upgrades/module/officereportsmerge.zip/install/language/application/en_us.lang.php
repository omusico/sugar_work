<?php
$app_list_strings['moduleList']['OfficeReportsMerge'] = 'Office Reports';

$app_list_strings['moduleList']['OfficeReportsVariables'] = 'Reports Variables';

$app_list_strings['moduleList']['OfficeReportsHistory'] = 'Reports History';

$app_list_strings['vars_for_reports'][''] = '';

$app_strings['LBL_GENERATE_BUTTON'] = 'Generate Document';

$app_strings['BOX_GET_FORM_PROCESS'] = 'Load settings. Please wait...';

$app_strings['BOX_HEADER_OFFICEFORM'] = 'Report Settings';

$app_strings['BOX_PLEASE_WAIT'] = 'Please wait...';

$app_strings['BOX_ERROR'] = 'Not recognized error.';

$app_strings['LBL_MODULE_TITLE'] = 'Office Reports';

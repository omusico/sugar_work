<?php
$app_list_strings['moduleList']['OfficeReportsMerge'] = 'Офисные отчеты';

$app_list_strings['moduleList']['OfficeReportsVariables'] = 'Переменные для отчетов';

$app_list_strings['moduleList']['OfficeReportsHistory'] = 'История отчетов';

$app_list_strings['vars_for_reports'][''] = '';

$app_strings['LBL_GENERATE_BUTTON'] = 'Сгенерировать документ';

$app_strings['BOX_GET_FORM_PROCESS'] = 'Получение параметров. Пожалуйста, подождите...';

$app_strings['BOX_HEADER_OFFICEFORM'] = 'Параметры отчета';

$app_strings['BOX_PLEASE_WAIT'] = 'Пожалуйста, подождите...';

$app_strings['BOX_ERROR'] = 'Неопознанная ошибка.';

$app_strings['LBL_MODULE_TITLE'] = 'Office Reports';

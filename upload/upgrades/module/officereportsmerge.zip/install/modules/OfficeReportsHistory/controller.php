<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once 'include/controller/Controller.php';

class OfficeReportsHistoryController extends SugarController
{
	public function __construct()
	{
		parent::SugarController();
	}

}
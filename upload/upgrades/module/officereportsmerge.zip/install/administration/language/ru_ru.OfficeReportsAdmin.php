<?php
$mod_strings['TH_LISTREPORT_TITLE'] = 'Список шаблонов';
$mod_strings['TH_LISTREPORT_DESC'] = 'Просмотр доступных шаблонов';

$mod_strings['TH_CREATEREPORT_TITLE'] = 'Загрузить шаблон';
$mod_strings['TH_CREATEREPORT_DESC'] = 'Загрузить новый шаблон';

$mod_strings['TH_SETTINGSREPORT_TITLE'] = 'Настройки';
$mod_strings['TH_SETTINGSREPORT_DESC'] = 'Настройки OfficeReports';

$mod_strings['TH_LISTTEMPLATEVARIABLE_TITLE'] = 'Переменные для шаблона';
$mod_strings['TH_LISTTEMPLATEVARIABLE_DESC'] = 'Список переменных доступных в шаблонах';

$mod_strings['TH_CREATETEMPLATEVARIABLE_TITLE'] = 'Создать переменную';
$mod_strings['TH_CREATETEMPLATEVARIABLE_DESC'] = 'Создать переменную для использования в шаблонах';

$mod_strings['TH_CODEVARIABLE_TITLE'] = 'Код для шаблона';
$mod_strings['TH_CODEVARIABLE_DESC'] = 'Просмотр кода для добавления в шаблоны';

$mod_strings['LBL_OFFICEREPORT_ADMIN_TITLE'] = 'Office Reports';
$mod_strings['LBL_OFFICEREPORT_ADMIN_DESCRIPTION'] = 'Создание, редактирование шаблонов для генерации Office Отчетов';

$mod_strings['TH_OFFICEREPORTHISTORY_TITLE'] = 'История';
$mod_strings['TH_OFFICEREPORTHISTORY_DESC'] = 'История отчетов';
?>

<?php
$mod_strings['TH_LISTREPORT_TITLE'] = 'Templates List';
$mod_strings['TH_LISTREPORT_DESC'] = 'Review list of templates';

$mod_strings['TH_CREATEREPORT_TITLE'] = 'Upload Template';
$mod_strings['TH_CREATEREPORT_DESC'] = 'Upload new template';

$mod_strings['TH_SETTINGSREPORT_TITLE'] = 'Settings';
$mod_strings['TH_SETTINGSREPORT_DESC'] = 'Settings OfficeReports';

$mod_strings['TH_LISTTEMPLATEVARIABLE_TITLE'] = 'Template Variable';
$mod_strings['TH_LISTTEMPLATEVARIABLE_DESC'] = 'Review list of variables for templates';

$mod_strings['TH_CREATETEMPLATEVARIABLE_TITLE'] = 'Create Template Variable';
$mod_strings['TH_CREATETEMPLATEVARIABLE_DESC'] = 'Create new variable for use in templates';

$mod_strings['TH_CODEVARIABLE_TITLE'] = 'Code for Template';
$mod_strings['TH_CODEVARIABLE_DESC'] = 'Show code for insert in template';

$mod_strings['LBL_OFFICEREPORT_ADMIN_TITLE'] = 'Office Reports';
$mod_strings['LBL_OFFICEREPORT_ADMIN_DESCRIPTION'] = 'Create and edit templates for generate in Office Reports';

$mod_strings['TH_OFFICEREPORTHISTORY_TITLE'] = 'History';
$mod_strings['TH_OFFICEREPORTHISTORY_DESC'] = 'History of generated reports';
?>
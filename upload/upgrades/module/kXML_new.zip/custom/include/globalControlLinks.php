<?php
/**
 * Created by Kolerts
 */
global $current_user;

if ($current_user->is_admin) {
    $global_control_links['kxml'] = array('linkinfo' => array('Конструктор XML'=>'index.php?module=kXML&action=index'));
}

<?php
$entry_point_registry['generate_xml'] = array('file' => 'modules/kXML/generate_xml.php' , 'auth' => '1'); 
?>
/**
 * Created by iluxovi4
 * Protected by SugarTalk.ru
 */
function open_pop_up(box) {
    sugarListView.get_checks(); // Получаем отмеченные записи
    $('#selected_ids').val(document.MassUpdate.uid.value); // Заносим в скрытый инпут ID всех записей через запятую
    $("#overlay").show();
    $(box).center_pop_up();
    $(box).show(500);
}

function close_pop_up(box) {
    $(box).hide(500);
    $("#overlay").delay(550).hide(1);
}

function getFieldsToExport()
{
    var arr = new Array();
    var i = 0;

    $('#right_multiselect option').each(function(){
        arr[i] = [ this.text, this.value ];
        i++;
    });

    arr[i] = ["module", $('#module_name').val()];
    arr[i+1] = ["records", $('#selected_ids').val()];

    //Если после закрытия окна с ссылкой на файл, пользователь решил еще раз запустить экспорт, восстанавливаем прежнее окно генерации файла
    $("#success_end > #success_end_message").text("");
    $("#fountainG").show();
    $(".close_success_box_button").hide();
    $("#loading_message").text("Генерация документа...");


    $.getJSON('index.php?module=Administration&action=xls_export&to_pdf=true&all_list='+$("#MassUpdate input[name=select_entire_list]").val(), {
        data: {
            param: JSON.stringify(arr)
        }
       },
        function(data){
            $("#fountainG").hide();
            $("#success_end > #success_end_message").append("Ссылка на скачивание файла <a href='" + data.result + "'>" + $("#module_name").val() + ".xls</a>");
            $("#loading_message").text("Сгенерирован успешно!").css("color", "green");
            $(".close_success_box_button").css("display", "inline-block");
        }
    );
}

jQuery.fn.center_pop_up = function(){
    this.css('position','absolute');
    this.css('top', ($(window).height() - this.height()) / 2+$(window).scrollTop() + 'px');
    this.css('left', ($(window).width() - this.width()) / 2+$(window).scrollLeft() + 'px');
}

// Предотвращаем лишние добавления элементов списка при нажатии на кнопку базовый поиск и расширенный поиск

if (!$("#actionLinkTop > .sugar_action_button > .subnav > li").hasClass('xls_li'))
{
    $('#actionLinkTop > .sugar_action_button > .subnav').append('<li class="xls_li"><a href="#" name="xls_export" id="xls_export" class="xls" onclick="open_pop_up(\'#pop-up\'); return false;">Экспортировать в Excel</a></li>');
}

if (!$("#actionLinkBottom > .sugar_action_button > .subnav > li").hasClass('xls_li'))
{
    $('#actionLinkBottom > .sugar_action_button > .subnav').append('<li class="xls_li"><a href="#" name="xls_export" id="xls_export" class="xls" onclick="open_pop_up(\'#pop-up\'); return false;">Экспортировать в Excel</a></li>');
}

$(document).ready(function(){
    $('#to_right').click( function()
    {
        var selected = $('#left_multiselect option:selected');
        $('#right_multiselect').append(selected);
        selected.attr('selected', false);
    });

    $('#to_left').click( function()
    {
        var selected = $('#right_multiselect option:selected');
        $('#left_multiselect').append(selected);
        selected.attr('selected', false);
    });

    $('#up').click( function(){
        $('#right_multiselect option:selected').each( function() {
            var newPos = $('#right_multiselect option').index(this) - 1;
            if (newPos > -1) {
                $('#right_multiselect option').eq(newPos).before("<option value='"+$(this).val()+"' selected='selected'>"+$(this).text()+"</option>");
                $(this).remove();
            }
        });
    });
    $('#down').click(function() {
        var countOptions = $('#right_multiselect option').size();
        $('#right_multiselect option:selected').each( function() {
            var newPos = $('#right_multiselect option').index(this) + 1;
            if (newPos < countOptions) {
                $('#right_multiselect option').eq(newPos).after("<option value='"+$(this).val()+"' selected='selected'>"+$(this).text()+"</option>");
                $(this).remove();
            }
        });
    });

    $('.submit_button').click(function(){

        if($("#right_multiselect option").size() > 0)
        {
            $("#pop-up").fadeOut(500);
            $("#success_end").fadeIn(600);
            $("#success_end").center_pop_up();
            getFieldsToExport();
        } else {
            alert("Вы не выбрали поля для экспорта!");
        }

    });

    $('.close_success_box_button').click(function(){
        close_pop_up("#success_end");
    });
    $('.cancel_button').click(function(){
        close_pop_up("#pop-up");
    });



});
<?php
$mod_strings['fieldTypes']['gallery'] = 'Галерея';
?>

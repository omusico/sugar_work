<?php
$mod_strings['GALLERY_IS_BY_DEFAULT'] = 'The value of the gallery can not put as default';
$mod_strings['GALLERY_IS_NOT_REPORTABLE'] = 'Field of the gallery is not available in reports';
$mod_strings['GALLERY_IS_NOT_IMPORTABLE'] = 'The field is not imported to the gallery';
$mod_strings['GALLERY_IS_NOT_MERGEABLE'] = 'Field of the gallery can not be used at the confluence of';

$mod_strings['GALLERY_TITLE_LABEL_WIDTH'] = 'The width of the gallery:';
$mod_strings['GALLERY_TITLE_LABEL_HEIGHT'] = 'The height of the gallery:';
$mod_strings['GALLERY_TITLE_OPTION_TURN_ON'] = 'Expand the default:';
?>

<?php
$mod_strings['fieldTypes']['gallery'] = 'Gallery';
?>

<?php
$app_strings['LBL_GALLERY_WARN'] = 'Вы ещё не загрузили фотографии!';
$app_strings['LBL_GALLERY_OPEN'] = 'Открыть галерею.';


?>

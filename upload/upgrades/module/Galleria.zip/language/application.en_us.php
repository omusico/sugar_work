<?php
$app_strings['LBL_GALLERY_WARN'] = 'You have not yet downloaded the pictures!';
$app_strings['LBL_GALLERY_OPEN'] = 'Open gallery.';


?>

<?php
$mod_strings['GALLERY_IS_BY_DEFAULT'] = 'Значение галереи нельзя поставить по умолчанию';
$mod_strings['GALLERY_IS_NOT_REPORTABLE'] = 'Поле с галереей не доступно в отчетах';
$mod_strings['GALLERY_IS_NOT_IMPORTABLE'] = 'Поле с галереей не импортируемое';
$mod_strings['GALLERY_IS_NOT_MERGEABLE'] = 'Поле с галереей не может использоваться при слиянии';

$mod_strings['GALLERY_TITLE_LABEL_WIDTH'] = 'Ширина галереи: ';
$mod_strings['GALLERY_TITLE_LABEL_HEIGHT'] = 'Высота галереи: ';
$mod_strings['GALLERY_TITLE_OPTION_TURN_ON'] = 'Разворачивать по-умолчанию: ';
?>

<?php

/**
 * function start before module start install
 */
function pre_install()
{
    /**
	if (check_already_install())
	{
		sugar_die('This module <b>already</b> installed. If you need install new version please uninstall current version <b style="color:red;">without delete database</b> and install new version of GalleryField.');
	}

     add following:
    $entry_point_registry['upload_photo'] = array('file' => 'custom/include/GalleryField/upload.php', 'auth' => true);
    $entry_point_registry['crop_photo'] = array('file' => 'custom/include/GalleryField/crop.php', 'auth' => true);
     */

    $add_entry_point = false;
    $new_contents = "";
    $entry_point_registry = null;
    if(file_exists("custom/include/MVC/Controller/entry_point_registry.php")){

        // This will load an array of the hooks to process
        include("custom/include/MVC/Controller/entry_point_registry.php");


        if(!isset($entry_point_registry['upload_photo'])) {
            $add_entry_point = true;
            $entry_point_registry['upload_photo'] = array('file' => 'custom/include/GalleryField/upload.php', 'auth' => true);
        }
        if(!isset($entry_point_registry['crop_photo'])) {
            $add_entry_point = true;
            $entry_point_registry['crop_photo'] = array('file' => 'custom/include/GalleryField/crop.php', 'auth' => true);
        }
    } else {
        $add_entry_point = true;
        $entry_point_registry['upload_photo'] = array('file' => 'custom/include/GalleryField/upload.php', 'auth' => true);
        $entry_point_registry['crop_photo'] = array('file' => 'custom/include/GalleryField/crop.php', 'auth' => true);
    }
    if($add_entry_point == true){

        require_once('include/utils/array_utils.php');
        require_once('include/utils/sugar_file_utils.php');

        foreach($entry_point_registry as $entryPoint => $epArray){
            $new_contents .= "\$entry_point_registry['".$entryPoint."'] = array('file' => '".$epArray['file']."' , 'auth' => '".$epArray['auth']."'); \n";
        }

        $new_contents = "<?php\n$new_contents\n?>";
        $file = 'custom/include/MVC/Controller/entry_point_registry.php';
        $paths = explode('/',$file);
        $dir = '';
        for($i = 0; $i < sizeof($paths) - 1; $i++)
        {
            if($i > 0) $dir .= '/';
            $dir .= $paths[$i];
            if(!file_exists($dir))
            {
                sugar_mkdir($dir, 0755);
            }
        }
        $fp = sugar_fopen($file, 'wb');
        fwrite($fp,$new_contents);
        fclose($fp);
    }

}

/**
 * check if this module already install
 * @return bool
 * 	return True if module already installed
function check_already_install()
{
	$uh = new UpgradeHistory();
	$uh->id_name = 'GalleryField';
	$result = $uh->checkForExisting($uh);

	if ($result != null)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}
*/
<?php

// function fired before ununstall module run
function pre_uninstall()
{
	$GLOBALS['log']->info('Start GalleryField pre uninstall functions');

	$current_level = error_reporting();
	error_reporting(0);// Remove all possible warning

    RemoveDir('upload/gallery_images');


    /** remove following:
    $entry_point_registry['upload_photo'] = array('file' => 'custom/modules/MyCustomEntry/upload_photo.php', 'auth' => true);
    $entry_point_registry['crop_photo'] = array('file' => 'custom/modules/MyCustomEntry/crop_photo.php', 'auth' => true);
     */
    $remove_entry_point = false;
    $new_contents = "";
    $entry_point_registry = null;
    if(file_exists("custom/include/MVC/Controller/entry_point_registry.php")){

        include("custom/include/MVC/Controller/entry_point_registry.php");

        if(isset($entry_point_registry['upload_photo'])) {
            $remove_entry_point = true;
            unset($entry_point_registry['upload_photo']);
        }
        if(isset($entry_point_registry['crop_photo'])) {
            $remove_entry_point = true;
            unset($entry_point_registry['crop_photo']);
        }
        if($remove_entry_point == true){

            require_once('include/utils/array_utils.php');
            require_once('include/utils/sugar_file_utils.php');

            foreach($entry_point_registry as $entryPoint => $epArray){
                $new_contents .= "\$entry_point_registry['".$entryPoint."'] = array('file' => '".$epArray['file']."' , 'auth' => '".$epArray['auth']."'); \n";
            }
            $new_contents = "<?php\n$new_contents\n?>";
            $file = 'custom/include/MVC/Controller/entry_point_registry.php';
            $fp = sugar_fopen($file, 'wb');
            fwrite($fp,$new_contents);
            fclose($fp);
        }

    }

    $GLOBALS['log']->info('End GalleryField pre uninstall functions');
}





function RemoveDir($path)
{
    if(file_exists($path) && is_dir($path))
    {
        $dirHandle = opendir($path);
        while (($file = readdir($dirHandle)) !== false)
        {
            if ($file != '.' && $file != '..')// исключаем папки с назварием '.' и '..'
            {
                $tmpPath = $path . '/' . $file;
                chmod($tmpPath, 0777);

                if (is_dir($tmpPath))
                {  // если папка
                    RemoveDir($tmpPath);
                }
                else
                {
                    if(file_exists($tmpPath))
                    {
                        // удаляем файл
                        unlink($tmpPath);
                    }
                }
            }
        }
        closedir($dirHandle);

        // удаляем текущую папку
        if(file_exists($path))
        {
            rmdir($path);
        }
    }
    else
    {
        //echo "Удаляемой папки не существует или это файл!";
    }
}
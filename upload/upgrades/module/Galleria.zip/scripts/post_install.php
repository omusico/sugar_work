<?php

// function fired after install module or after uninstall module
function post_install()
{
	if ($_REQUEST['mode'] == 'Install')
	{
		// install
		$GLOBALS['log']->info('Start GalleryField post install functions');

        if(!is_dir('upload'))
        {
            mkdir('upload', 0775);
        }

		repair_and_rebuild(); // auto repair and rebuild all changes
		
		$GLOBALS['log']->info('End GalleryField post install functions');
	}
	else
	{
		// uninstall
		$GLOBALS['log']->info('Start GalleryField post uninstall functions');

		$GLOBALS['log']->info('End GalleryField post uninstall functions');
	}
}

function repair_and_rebuild()
{
	// it's function auto repair and rebuild all changes, without user intervention
	require_once('modules/Administration/QuickRepairAndRebuild.php');

	// changed function
	$repair_modules = array ('GalleryField');
	// repair action
	$repair_actions = array (
		'clearTpls',
		'clearJsFiles',
		'clearVardefs',
		'clearJsLangFiles',
		'rebuildExtensions',
		'clearLangFiles',
		'repairDatabase',
		'clearThemeCache',
	);

	$RepairAndClear = new RepairAndClear();
	$RepairAndClear->repairAndClearAll($repair_actions, $repair_modules, $autoexecute = true, $show_output = false);

	// repair ACL for new module
	ACLAction::addActions('GalleryField');

	return TRUE;
}


?>
